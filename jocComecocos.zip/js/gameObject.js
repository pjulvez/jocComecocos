class GameObject {

  constructor(x,y) {
      this.coordX = x;
      this.coordY = y;
    }

}
